function main() {
          // hier komt je code
}

window.onload = function() {
       main();
}
